import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/transaction_model.dart';

class TransactionProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<TransactionModel> _transactions = [];
  bool _isLoading = false;

  // Data Analitik yang dihitung
  double _totalRevenue = 0.0;
  double _totalCost = 0.0;
  double _totalProfit = 0.0;
  int _transactionCount = 0;

  List<TransactionModel> get transactions => _transactions;
  bool get isLoading => _isLoading;
  double get totalRevenue => _totalRevenue;
  double get totalCost => _totalCost;
  double get totalProfit => _totalProfit;
  int get transactionCount => _transactionCount;

  // --- Fungsi Utama untuk Mengambil dan Menghitung Data ---
  Future<void> fetchTransactions() async {
    _isLoading = true;
    notifyListeners();

    try {
      // Menggunakan onSnapshot untuk real-time updates (opsional, tapi bagus)
      _firestore.collection('transactions').snapshots().listen((snapshot) {
        _transactions = snapshot.docs
            .map((doc) => TransactionModel.fromFirestore(doc))
            .toList();

        // Setelah data diambil, hitung analitik
        _calculateAnalytics();

        _isLoading = false;
        notifyListeners();
      });
    } catch (e) {
      debugPrint('Error fetching transactions: $e');
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- Fungsi Perhitungan Analitik ---
  void _calculateAnalytics() {
    _totalRevenue = 0.0;
    _totalCost = 0.0;
    _transactionCount = 0;

    for (var transaction in _transactions) {
      // Hanya hitung transaksi yang sudah selesai
      if (transaction.status == TransactionStatus.completed) {
        _totalRevenue += transaction.totalAmount;
        _totalCost += transaction.totalCostPrice;
        _transactionCount++;
      }
    }

    // Keuntungan = Penjualan - Modal
    _totalProfit = _totalRevenue - _totalCost;
  }
}