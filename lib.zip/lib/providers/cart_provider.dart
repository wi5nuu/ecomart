import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/cart_item_model.dart';
import '../models/product_model.dart';
import '../models/transaction_model.dart';

// Variabel global dari Canvas
final firebaseConfig = const String.fromEnvironment('FIREBASE_CONFIG');
const String __app_id = 'default-app-id';
final String appId = const bool.fromEnvironment('dart.vm.product')
    ? const String.fromEnvironment('APP_ID')
    : __app_id;

class CartProvider with ChangeNotifier {
  // Map to store cart items locally: {productId: CartItemModel}
  final Map<String, CartItemModel> _items = {};

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  StreamSubscription<QuerySnapshot>? _cartSubscription;

  // --- Getters ---

  List<CartItemModel> get items => _items.values.toList();
  int get itemCount => _items.values.fold(0, (sum, item) => sum + item.quantity);
  double get totalAmount {
    return _items.values.fold(0.0, (sum, item) => sum + item.totalPrice);
  }
  double get totalCostAmount {
    return _items.values.fold(0.0, (sum, item) => sum + item.totalCost);
  }

  // --- Firestore Utility & Listener ---

  String? get currentUserId => _auth.currentUser?.uid;

  CollectionReference<Map<String, dynamic>> _getCartCollection() {
    final userId = currentUserId;
    if (userId == null) {
      debugPrint('Error: User ID is null. Cannot access user cart.');
      throw Exception('User not authenticated.');
    }

    // Path: /artifacts/{appId}/users/{userId}/cart
    return _firestore.collection('artifacts')
        .doc(appId)
        .collection('users')
        .doc(userId)
        .collection('cart');
  }

  // Called after authentication is ready to start listening to the cart.
  void setupCartListener() {
    _cartSubscription?.cancel();
    _items.clear();
    notifyListeners();

    if (currentUserId == null) {
      debugPrint("Cart Listener: User not logged in, skipping Firestore listener.");
      return;
    }

    debugPrint("Cart Listener: Starting to listen to cart for UID: $currentUserId");

    try {
      _cartSubscription = _getCartCollection()
          .snapshots()
          .listen((snapshot) {
        _items.clear();
        for (var doc in snapshot.docs) {
          final data = doc.data();
          final item = CartItemModel.fromMap(data);
          _items[item.productId] = item;
        }

        debugPrint("Cart updated. Total unique items: ${_items.length}");
        notifyListeners(); // Notify UI after data is received from Firestore
      }, onError: (error) {
        debugPrint("Error loading cart from Firestore: $error");
      });
    } catch (e) {
      debugPrint("Failed to setup cart listener: $e");
    }
  }

  @override
  void dispose() {
    _cartSubscription?.cancel();
    super.dispose();
  }

  // --- Persistent Cart Operations ---

  Future<void> addItem(ProductModel product, {int quantity = 1}) async {
    if (currentUserId == null) return;

    if (product.stock <= 0) {
      debugPrint('Stock for product ${product.name} is zero.');
      return;
    }

    int currentQuantityInCart = _items[product.id]?.quantity ?? 0;
    if (currentQuantityInCart + quantity > product.stock) {
      debugPrint('Requested quantity exceeds available stock (${product.stock}).');
      return;
    }

    final newCartItem = CartItemModel(
      id: DateTime.now().toString(),
      productId: product.id!,
      name: product.name,
      price: product.price,
      costPrice: product.costPrice,
      quantity: quantity,
      imageUrl: product.imageUrl,
    );

    final itemDocRef = _getCartCollection().doc(product.id);

    if (_items.containsKey(product.id)) {
      await itemDocRef.update({
        'quantity': FieldValue.increment(quantity)
      });
      debugPrint('Item ${product.name} quantity incremented in Firestore.');
    } else {
      await itemDocRef.set(newCartItem.toMapForTransaction());
      debugPrint('New item ${product.name} added to Firestore.');
    }
  }

  // Helper methods for other cart operations (omitted for brevity)
  Future<void> incrementQuantity(String productId) async { /* ... */ }
  Future<void> decrementQuantity(String productId) async { /* ... */ }
  Future<void> removeItem(String productId) async { /* ... */ }
  Future<void> clearCart() async { /* ... */ }
  Future<void> checkout() async { /* ... */ }
}