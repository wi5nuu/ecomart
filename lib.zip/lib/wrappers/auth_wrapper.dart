// lib/wrappers/auth_wrapper.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';

import '../screens/admin_analytics_screen.dart';
import '../screens/home_screen.dart';
import '../screens/login_screen.dart';
import '../screens/splash_screen.dart';

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    // 1. Menunggu Firebase selesai cek session
    if (!auth.isAuthReady) {
      return const SplashScreen();
    }

    // 2. Jika tidak ada user (atau gagal ambil data Firestore) → login
    if (!auth.isAuthenticated || auth.currentUser == null) {
      // Jika isAuthenticated true tetapi currentUser null, berarti user ada di Auth
      // tapi tidak ada di Firestore. Kita tetap kembalikan ke Login
      // atau mungkin ke halaman error jika ini dianggap masalah serius.
      return const LoginScreen();
    }

    // 3. User authenticated dan data Firestore sudah diambil (auth.currentUser != null)

    // Periksa Peran Admin
    if (auth.currentUser!.isAdmin) {
      // PERBAIKAN: Mengganti AdminAnalyticysScreen menjadi AdminAnalyticsScreen
      return const AdminAnalyticsScreen(); // Navigasi ke Halaman Admin
    }

    // Peran Client (Default)
    return const HomeScreen(); // Navigasi ke Halaman Client/Home
  }
}