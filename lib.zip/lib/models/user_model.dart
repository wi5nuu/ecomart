import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Menambahkan kembali untuk kompatibilitas umum

class UserModel {
  final String? id; // ID Firestore/Firebase Auth
  final String name;
  final String email;
  final String phone;
  final String address;
  final String gender;
  final bool isAdmin; // Menggantikan 'role'
  final bool agreeToTerms;

  UserModel({
    this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
    required this.gender,
    this.isAdmin = false, // Default ke false
    required this.agreeToTerms,
  });

  // Digunakan untuk menyimpan data ke Firestore
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'address': address,
      'gender': gender,
      'isAdmin': isAdmin,
      'agreeToTerms': agreeToTerms,
    };
  }

  // Factory method: Digunakan untuk mengambil data dari Firestore
  factory UserModel.fromMap(String id, Map<String, dynamic> map) {
    return UserModel(
      id: id,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
      address: map['address'] ?? '',
      gender: map['gender'] ?? 'Laki-laki',
      isAdmin: map['isAdmin'] ?? false,
      agreeToTerms: map['agreeToTerms'] ?? false,
    );
  }

  // Metode untuk membuat salinan (copyWith). Ini penting untuk Provider.
  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? address,
    String? gender,
    bool? isAdmin,
    bool? agreeToTerms,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      gender: gender ?? this.gender,
      isAdmin: isAdmin ?? this.isAdmin,
      agreeToTerms: agreeToTerms ?? this.agreeToTerms,
    );
  }
}