import 'package:cloud_firestore/cloud_firestore.dart';
import 'cart_item_model.dart';

// Enum untuk Status Transaksi
enum TransactionStatus { pending, completed, cancelled }

class TransactionModel {
  final String id;
  final String userId;
  final double totalAmount; // Total Harga Jual
  final List<CartItemModel> items;
  final DateTime transactionDate;
  final TransactionStatus status;
  // Cost Price (Harga Pokok Penjualan) diperlukan untuk menghitung Keuntungan/Kerugian
  final double totalCostPrice;

  TransactionModel({
    required this.id,
    required this.userId,
    required this.totalAmount,
    required this.items,
    required this.transactionDate,
    this.status = TransactionStatus.pending,
    required this.totalCostPrice,
  });

  // Helper untuk mendapatkan status sebagai string (contoh: 'completed')
  String get statusString => status.toString().split('.').last;

  // Konversi dari Firestore Document/Snapshot
  factory TransactionModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>?;

    // 1. Konversi daftar item yang disimpan di Firestore
    final itemsList = (data?['items'] as List<dynamic>?)
    // Map setiap item map menjadi objek CartItemModel
        ?.map((itemMap) => CartItemModel.fromMap(itemMap as Map<String, dynamic>))
        .toList() ?? [];

    // 2. Konversi status string menjadi Enum
    final statusValue = data?['status'] ?? 'pending';
    final transactionStatus = TransactionStatus.values.firstWhere(
          (e) => e.toString().split('.').last == statusValue,
      orElse: () => TransactionStatus.pending,
    );

    return TransactionModel(
      id: doc.id,
      userId: data?['userId'] ?? 'Unknown',
      totalAmount: (data?['totalAmount'] ?? 0).toDouble(),
      totalCostPrice: (data?['totalCostPrice'] ?? 0).toDouble(),
      items: itemsList,
      // 3. Konversi Firestore Timestamp ke DateTime
      transactionDate: (data?['transactionDate'] is Timestamp) ? (data?['transactionDate'] as Timestamp).toDate() : DateTime.now(),
      status: transactionStatus,
    );
  }

  // Konversi ke Map untuk disimpan di Firestore
  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'totalAmount': totalAmount,
      'totalCostPrice': totalCostPrice,
      // Konversi List<CartItemModel> menjadi List<Map<String, dynamic>>
      'items': items.map((item) => item.toMapForTransaction()).toList(),
      'transactionDate': Timestamp.fromDate(transactionDate),
      'status': statusString,
    };
  }
}