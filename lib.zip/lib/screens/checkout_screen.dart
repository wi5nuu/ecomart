import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/checkout_model.dart';
import '../providers/cart_provider.dart';
// NOTE: Ganti dengan path dan nama file layar produk Anda yang sebenarnya jika berbeda
import 'products_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  late CheckoutModel _checkoutData;

  final List<String> _jabodetabekCities = [
    'Jakarta',
    'Bogor',
    'Depok',
    'Tangerang',
    'Bekasi',
  ];

  @override
  void initState() {
    super.initState();
    final cartProvider = Provider.of<CartProvider>(context, listen: false);

    _checkoutData = CheckoutModel(
      subtotal: cartProvider.totalAmount,
    );

    _calculateShippingCost();
  }

  void _calculateShippingCost() {
    setState(() {
      final city = _checkoutData.city;
      final isJabodetabek = _jabodetabekCities.contains(city);

      if (isJabodetabek) {
        _checkoutData.shippingCost = 0.0;
      } else {
        _checkoutData.shippingCost = 15000.0;
      }
    });
  }

  void _applyVoucher(String code) {
    _checkoutData.discountAmount = 0.0;

    setState(() {
      _checkoutData.voucherCode = code.toUpperCase();

      if (code.toUpperCase() == 'DISKON10') {
        _checkoutData.discountAmount = _checkoutData.subtotal * 0.1;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voucher DISKON10 berhasil diterapkan!')),
        );
      } else if (code.toUpperCase() == 'HEMAT5K') {
        _checkoutData.discountAmount = 5000.0;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voucher HEMAT5K berhasil diterapkan!')),
        );
      } else if (code.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voucher tidak valid atau kadaluarsa.'), backgroundColor: Colors.red),
        );
      }
    });
  }

  // Logika Akhir: Proses Pembayaran
  void _processPayment() {
    if (_checkoutData.selectedAddress == 'Pilih Alamat Pengiriman' || _checkoutData.selectedAddress.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mohon pilih alamat pengiriman terlebih dahulu.'), backgroundColor: Colors.red),
      );
      return;
    }

    if (_checkoutData.paymentMethod == 'Pilih Metode Pembayaran' || _checkoutData.paymentMethod.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mohon pilih metode pembayaran.'), backgroundColor: Colors.red),
      );
      return;
    }

    final cartProvider = Provider.of<CartProvider>(context, listen: false);
    cartProvider.clearCart();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Pembayaran sebesar Rp ${_checkoutData.totalFinal.toStringAsFixed(0)} Sukses! Pesanan sedang diproses.'),
        duration: const Duration(seconds: 4),
        backgroundColor: Colors.green,
      ),
    );

    // Menggunakan pushAndRemoveUntil untuk kembali ke ProductsScreen
    // dan menghapus semua layar di tumpukan navigasi (termasuk Registrasi, Keranjang, Checkout)
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        // Pastikan ProductsScreen() adalah nama widget layar produk Anda
        builder: (context) => const ProductsScreen(),
      ),
          (Route<dynamic> route) => false, // Ini memastikan semua rute sebelumnya dihapus
    );
  }

  // --- WIDGET UNTUK UI CHECKOUT ---

  Widget _buildAddressSection() {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: const Icon(Icons.location_on, color: Colors.blue),
        title: const Text('Alamat Pengiriman', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(_checkoutData.selectedAddress),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () async {
          final selectedCity = await showModalBottomSheet<String>(
            context: context,
            builder: (context) => _buildCitySelector(context),
          );

          if (selectedCity != null) {
            setState(() {
              _checkoutData.city = selectedCity;
              _checkoutData.selectedAddress = 'Jalan Melati No. 12, Kel. Sentosa, Kota $selectedCity, Indonesia';
              _calculateShippingCost();
            });
          }
        },
      ),
    );
  }

  Widget _buildCitySelector(BuildContext context) {
    List<String> allCities = ['Jakarta', 'Bogor', 'Depok', 'Tangerang', 'Bekasi', 'Bandung', 'Surabaya', 'Medan', 'Yogyakarta'];
    return Container(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Pilih Kota Pengiriman', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          SizedBox(
            height: 250,
            child: ListView(
              children: allCities.map((city) => ListTile(
                title: Text(city, style: TextStyle(color: _jabodetabekCities.contains(city) ? Colors.green : Colors.black)),
                trailing: _jabodetabekCities.contains(city) ? const Text('GRATIS ONGKIR', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)) : null,
                onTap: () => Navigator.pop(context, city),
              )).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoucherSection() {
    final voucherController = TextEditingController(text: _checkoutData.voucherCode);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Voucher Diskon', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: voucherController,
                    decoration: InputDecoration(
                        hintText: 'Masukkan kode voucher (DISKON10/HEMAT5K)',
                        isDense: true,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                        contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10)
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => _applyVoucher(voucherController.text),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12)
                  ),
                  child: const Text('Terapkan'),
                ),
              ],
            ),
            if (_checkoutData.discountAmount > 0)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text('Diskon Rp ${_checkoutData.discountAmount.toStringAsFixed(0)} berhasil diterapkan!', style: const TextStyle(color: Colors.green)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentSection() {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: const Icon(Icons.credit_card, color: Colors.green),
        title: const Text('Metode Pembayaran', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(_checkoutData.paymentMethod),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () async {
          final selectedMethod = await showModalBottomSheet<String>(
            context: context,
            builder: (context) => _buildPaymentMethodSelector(context),
          );

          if (selectedMethod != null) {
            setState(() {
              _checkoutData.paymentMethod = selectedMethod;
            });
          }
        },
      ),
    );
  }

  Widget _buildPaymentMethodSelector(BuildContext context) {
    List<String> methods = ['Transfer Bank BNI', 'Transfer Bank Mandiri', 'Gopay', 'OVO', 'Bayar di Tempat (COD)'];
    return Container(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Pilih Metode Pembayaran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          SizedBox(
            height: 250,
            child: ListView(
              children: methods.map((method) => ListTile(
                title: Text(method),
                onTap: () => Navigator.pop(context, method),
              )).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummarySection() {
    return Card(
      margin: const EdgeInsets.only(bottom: 100),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Rincian Pembayaran', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Divider(),
            _buildSummaryRow('Subtotal Produk', _checkoutData.subtotal, color: Colors.black54),
            _buildSummaryRow('Ongkos Kirim', _checkoutData.shippingCost,
                color: _checkoutData.shippingCost == 0.0 ? Colors.green : Colors.orange,
                isShipping: true, city: _checkoutData.city),
            _buildSummaryRow('Diskon Voucher', -_checkoutData.discountAmount, color: Colors.red),
            const Divider(height: 20, thickness: 2),
            _buildSummaryRow('Total Pembayaran', _checkoutData.totalFinal, color: Colors.blue.shade700, isTotal: true),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String title, double amount, {Color color = Colors.black, bool isTotal = false, bool isShipping = false, String? city}) {
    String detailText = '';
    if (isShipping) {
      if (amount == 0.0) {
        detailText = '(Gratis Ongkir ke $city!)';
      } else {
        detailText = '(Reguler ke $city)';
      }
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Text(
                title,
                style: TextStyle(fontSize: isTotal ? 18 : 16, fontWeight: isTotal ? FontWeight.bold : FontWeight.normal),
              ),
              if (detailText.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(left: 4.0),
                  child: Text(
                    detailText,
                    style: TextStyle(fontSize: 12, color: color, fontStyle: FontStyle.italic),
                  ),
                ),
            ],
          ),
          Text(
            'Rp ${amount.abs().toStringAsFixed(0)}',
            style: TextStyle(
              fontSize: isTotal ? 20 : 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Checkout Pembayaran'),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildAddressSection(),
            _buildVoucherSection(),
            _buildPaymentSection(),
            _buildSummarySection(),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, -5)),
          ],
        ),
        child: SafeArea(
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.payment, color: Colors.white),
              label: Text(
                'Bayar Sekarang (Rp ${_checkoutData.totalFinal.toStringAsFixed(0)})',
                style: const TextStyle(color: Colors.white, fontSize: 18),
              ),
              onPressed: cartProvider.itemCount > 0 &&
                  _checkoutData.totalFinal > 0.0 &&
                  _checkoutData.selectedAddress != 'Pilih Alamat Pengiriman' &&
                  _checkoutData.paymentMethod != 'Pilih Metode Pembayaran'
                  ? _processPayment : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}