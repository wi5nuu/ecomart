import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../models/product_model.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // === USER METHODS ===
  Future<void> saveUser(UserModel user) async {
    try {
      // PERBAIKAN: Mengganti user.uid menjadi user.id
      // ID dokumen di Firestore disamakan dengan ID user (UID Firebase Auth)
      // Kita menggunakan 'id!' karena kita berasumsi ID sudah diisi oleh AuthProvider
      await _firestore.collection('users').doc(user.id!).set(user.toMap());
    } catch (e) {
      throw Exception('Gagal menyimpan user: $e');
    }
  }

  // Metode untuk mengambil user berdasarkan UID (ID Dokumen)
  Future<UserModel?> getUser(String uid) async {
    try {
      // UID yang diterima dari Firebase Auth digunakan sebagai ID dokumen
      final doc = await _firestore.collection('users').doc(uid).get();

      if (doc.exists && doc.data() != null) {
        // ID dokumen (doc.id) akan menjadi nilai untuk field id di UserModel
        return UserModel.fromMap(doc.id, doc.data()!);
      }
      return null;
    } catch (e) {
      throw Exception('Gagal mengambil user berdasarkan UID: $e');
    }
  }

  Future<bool> isEmailRegistered(String email) async {
    try {
      final query = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .get();
      return query.docs.isNotEmpty;
    } catch (e) {
      throw Exception('Gagal memeriksa email: $e');
    }
  }

  Future<UserModel?> getUserByEmail(String email) async {
    try {
      final query = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .get();

      if (query.docs.isNotEmpty) {
        // Menggunakan ID dokumen sebagai ID user
        return UserModel.fromMap(query.docs.first.id, query.docs.first.data());
      }
      return null;
    } catch (e) {
      throw Exception('Gagal mengambil user: $e');
    }
  }

  // === PRODUCT METHODS ===
  Future<List<ProductModel>> getProducts() async {
    try {
      final query = await _firestore
          .collection('products')
          .orderBy('createdAt', descending: true)
          .get();

      return query.docs.map((doc) {
        return ProductModel.fromMap(doc.id, doc.data());
      }).toList();
    } catch (e) {
      throw Exception('Gagal mengambil produk: $e');
    }
  }

  Future<List<ProductModel>> getProductsByCategory(String category) async {
    try {
      final query = await _firestore
          .collection('products')
          .where('category', isEqualTo: category)
          .get();

      return query.docs.map((doc) {
        return ProductModel.fromMap(doc.id, doc.data());
      }).toList();
    } catch (e) {
      throw Exception('Gagal mengambil produk by category: $e');
    }
  }

  Future<String> addProduct(ProductModel product) async {
    try {
      final docRef = await _firestore.collection('products').add(product.toMap());
      return docRef.id; // Mengembalikan ID dokumen yang baru dibuat
    } catch (e) {
      throw Exception('Gagal menambah produk: $e');
    }
  }

  Future<ProductModel?> getProductById(String id) async {
    try {
      final doc = await _firestore.collection('products').doc(id).get();
      if (doc.exists) {
        return ProductModel.fromMap(doc.id, doc.data()!);
      }
      return null;
    } catch (e) {
      throw Exception('Gagal mengambil produk: $e');
    }
  }
}